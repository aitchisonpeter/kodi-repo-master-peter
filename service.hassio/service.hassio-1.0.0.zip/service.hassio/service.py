import os
import sys
import xbmc
import xbmcaddon
import json
from json import loads

###############################################################################

_addonid = 'service.hassio'
_addon = xbmcaddon.Addon(id=_addonid)
_S_ = _addon.getSetting
_STR_ = _addon.getLocalizedString

try:
    _addon_path = _addon.getAddonInfo('path').decode('utf-8')
except TypeError:
    _addon_path = _addon.getAddonInfo('path').decode()
try:
    _base_resource = xbmc.translatePath(os.path.join(
        _addon_path,
        'resources',
        'lib')).decode('utf-8')
except TypeError:
    _base_resource = xbmc.translatePath(os.path.join(
        _addon_path,
        'resources',
        'lib')).decode()
sys.path.append(_base_resource)

###############################################################################

from theater_controller import TheaterController
from hassio import Hassio
import util
import ui

class HassioService(xbmc.Monitor):
    def __init__(self):
        super(HassioService, self).__init__()
        self.wasPaused = False
        self.hassio = Hassio()
        self.loadSettings()
        self.connect()

    def loadSettings(self):
        _addon = xbmcaddon.Addon(id=_addonid)
        _S_ = _addon.getSetting
        _STR_ = _addon.getLocalizedString

    def connect(self):
        if not _S_('hassio_host') or not _S_('hassio_password'):
            util.notify(_STR_(506010))
            return

        self.hassio.set_credentials(_S_('hassio_host'), _S_('hassio_password'))

        if self.hassio.connected:
            util.notice('Successfully connected to {}'.format(_S_('hassio_host')))
            util.notify('Home Assistant', _STR_(506020).format(_S_('hassio_host')))
            self.updateControllers()
        else:
            util.error('Could not connect to {}'.format(_S_('hassio_host')))
            util.notify('Home Assistant', _STR_(506030).format(_S_('hassio_host')))

    def updateControllers(self):
        self.theater_controller = TheaterController(
            hassio=self.hassio,
            lights=_S_('theater_group').split(','),
            start_bri=_S_('theater_start_bri'),
            pause_bri_override=_S_('theater_pause_bri_override'),
            pause_bri=_S_('theater_pause_bri'),
            stop_bri_override=_S_('theater_stop_bri_override'),
            stop_bri=_S_('theater_stop_bri'),
            force_light_on=_S_('force_light_on')
        )

        util.debug('Instantiated the following controllers {}'.format(self.theater_controller))

    def onSettingsChanged(self):
        previousHassioHost = _S_('hassio_host')
        previousHassioPassword = _S_('hassio_password')

        self.loadSettings()

        if not self.hassio.connected or previousHassioHost != _S_('hassio_host') or previousHassioPassword != _S_('hassio_password'):
            util.debug('Connection settings (host/password) have changed - trying to connect')
            self.connect()
        else:
            util.debug('Settings have changed - updating controllers')
            self.updateControllers()

    def onNotification(self, sender, method, data):
        util.debug('notification received (sender={}, method={}, data={})'.format(sender, method, data))

        if not self.hassio.connected:
            util.warn('Not connected - discarding received notification')
            return
        
        data = loads(data)

        if sender == 'xbmc':
            if method == 'Player.OnPlay':
                self.playbackStateChanged('resumed' if self.wasPaused else 'started', data)
            elif method == 'Player.OnPause':
                self.playbackStateChanged('paused', data)
            elif method == 'Player.OnStop':
                self.playbackStateChanged('stopped', data)
        elif sender == _addonid:
            if method == 'Other.start_setup_theater_lights':
                ret = ui.multiselect_lights(self.hassio, _STR_(501210), _S_('theater_group').split(',') if _S_('theater_group') else [])
                util.debug('Selected {} for theater group'.format(ret))
                _addon.setSetting(id='theater_group', value=','.join(ret))
            elif method == 'Other.start_setup_itemtypes':
                ret = ui.multiselect_itemtypes(_STR_(501130), _S_('act_on_itemtypes').split(',') if _S_('act_on_itemtypes') else [])
                util.debug('Selected {} as applicable itemtypes'.format(ret))
                _addon.setSetting(id='act_on_itemtypes', value=','.join(ret))

    def playbackStateChanged(self, state, data):
        try:
            itemtype = data['item']['type']
        except (TypeError, KeyError) as e:
            util.warn('Invalid itemtype on playback status event - assuming None - {}'.format(e))
            itemtype = None

        if itemtype in _S_('act_on_itemtypes').split(','):
            if state == 'started':
                self.wasPaused = False
                self.theater_controller.onPlaybackStarted()
            elif state == 'resumed':
                self.wasPaused = False
                self.theater_controller.onPlaybackResumed()
            elif state == 'paused':
                self.wasPaused = True
                self.theater_controller.onPlaybackPaused()
            elif state == 'stopped':
                self.wasPaused = False
                self.theater_controller.onPlaybackStopped()

    def run(self):
        util.notice('Started')
        while not self.abortRequested():
            if self.waitForAbort(1):
                util.notice('Abort requested - shutting down service')
                break

if __name__ == '__main__':
    HassioService().run()