class Light:
	def __init__(self, entity_id):
		self.entity_id = entity_id
		self.initial_state = { 'entity_id': entity_id, 'attributes': [] }