import xbmcgui

def multiselect(title, items, selected_items):
    preselect_indices = map(lambda item: items.index(item), selected_items) if selected_items else []
    selected = xbmcgui.Dialog().multiselect(title, items, preselect=preselect_indices)

    return map(lambda index: items[index], selected) if selected else []

def multiselect_lights(hassio, title, selected_items):
    items = map(lambda light: light['entity_id'], filter(lambda entity: 'light.' in entity['entity_id'], hassio.get_states()))
    return multiselect(title, items, selected_items)

def multiselect_itemtypes(title, selected_items):
    return multiselect(title, ['movie', 'episode', 'channel'], selected_items)