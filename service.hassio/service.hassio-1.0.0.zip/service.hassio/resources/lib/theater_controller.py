import util

class TheaterController:
    def __init__(self, hassio, lights, start_bri, pause_bri_override, pause_bri, stop_bri_override, stop_bri, force_light_on):
        self.hassio = hassio
        self.lights = lights
        self.initial_states = dict.fromkeys(lights)
        self.start_bri = start_bri
        self.pause_bri_override = pause_bri_override.lower() == 'true'
        self.pause_bri = pause_bri
        self.stop_bri_override = stop_bri_override.lower() == 'true'
        self.stop_bri = stop_bri
        self.force_light_on = force_light_on

    def save_initial_states(self):
        try:
            self.initial_states.update(
                map(lambda e: (e['entity_id'], e),
                    filter(lambda s: s['entity_id'] in self.lights,
                        self.hassio.get_states()
                    )
                )
            )
            util.debug('TheaterController - saved initial states - {}'.format(self.initial_states))
        except Exception:
            util.error('Unable to obtain initial states from {}'.format(self.hassio.host))

    def dim_lights(self, brightness, restore_initial_state=False):
        if restore_initial_state:
            for entity_id, state in self.initial_states.iteritems():
                if self.force_light_on or state['state'] == 'on':
                    self.hassio.set_light_state(
                        [entity_id],
                        state['state'],
                        0 if state['state'] == 'off' else state['attributes']['brightness']
                    )
        else:
            self.hassio.set_light_state(
                filter(lambda l: self.force_light_on or self.initial_states[l]['state'] == 'on', self.lights),
                'on',
                brightness
            )

    def onPlaybackStarted(self):
        self.save_initial_states()
        util.debug('TheaterController.onPlaybackStarted - dimming lights to {}'.format(self.start_bri))
        self.dim_lights(self.start_bri)

    def onPlaybackResumed(self):
        util.debug('TheaterController.onPlaybackResumed - dimming lights to {}'.format(self.start_bri))
        self.dim_lights(self.start_bri)

    def onPlaybackPaused(self):
        util.debug('TheaterController.onPlaybackPaused - un-dimming lights to {}'.format(self.pause_bri if self.pause_bri_override else 'their initial values'))
        self.dim_lights(self.pause_bri, not self.pause_bri_override)

    def onPlaybackStopped(self):
        util.debug('TheaterController.onPlaybackStopped - un-dimming lights to {}'.format(self.stop_bri if self.stop_bri_override else 'their initial values'))
        self.dim_lights(self.stop_bri, not self.stop_bri_override)

    def __repr__(self):
        return ('<{} {}, start={}, pause_override={}, pause={}, stop_override={}, stop={}, force={}>'.format(self.__class__.__name__, self.lights, self.start_bri, self.pause_bri_override, self.pause_bri, self.stop_bri_override, self.stop_bri, self.force_light_on))