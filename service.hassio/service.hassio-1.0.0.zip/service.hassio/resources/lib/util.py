import xbmc
import xbmcaddon
import os

__addon__ = xbmcaddon.Addon()
__cwd__ = __addon__.getAddonInfo('path')
__icon__ = os.path.join(__cwd__, "icon.png")

__msgtemplate = 'service.hassio: {}'

def fatal(msg):
    xbmc.log(__msgtemplate.format(msg), xbmc.LOGFATAL)

def severe(msg):
    xbmc.log(__msgtemplate.format(msg), xbmc.LOGSEVERE)

def error(msg):
    xbmc.log(__msgtemplate.format(msg), xbmc.LOGERROR)

def warn(msg):
    xbmc.log(__msgtemplate.format(msg), xbmc.LOGWARNING)

def notice(msg):
    xbmc.log(__msgtemplate.format(msg), xbmc.LOGNOTICE)

def debug(msg):
    xbmc.log(__msgtemplate.format(msg), xbmc.LOGDEBUG)

def notify(title, msg=''):
    xbmc.executebuiltin('XBMC.Notification({}, {}, 3, {})'.format(title, msg, __icon__))