import util

try:
    import requests
except ImportError:
    util.notify("Home Assistant", "ERROR: Could not import Python requests")

class Hassio():
    __timeout = 2.5

    def __headers(self, password):
        return { 'x-ha-access': password }
    
    def __url(self, host, path=None):
        path = path if path else ''
        return '{}/api'.format(host) + path
    
    def __clip(self, val, min, max):
        if val < min:
            return min
        elif val > max:
            return max
        else:
            return val
    
    def __init__(self):
        self.connected = False

    def set_credentials(self, host, password):
        self.host = host
        self.password = password
        self.connected = self.say_hello()

    def say_hello(self):
        try:
            res = requests.get(self.__url(self.host, '/'), headers=self.__headers(self.password), timeout=self.__timeout)
        except requests.RequestException as e:
            util.debug('say_hello failed with exception {}'.format(e))
            return False
        
        util.debug('response to say_hello with status code {}'.format(res.status_code))

        return res.status_code == 200

    def get_states(self):
        return requests.get(self.__url(self.host, '/states'), headers=self.__headers(self.password), timeout=self.__timeout).json()

    def call_service(self, domain, service, service_data):
        url = self.__url(self.host, '/services/{}/{}'.format(domain, service))
        util.debug('POST to {} with service_data {}'.format(url, service_data))

        try:
            res = requests.post(url, headers=self.__headers(self.password), json=service_data, timeout=self.__timeout)
        except Exception as e:
            util.error('Service call failed with exception {}'.format(e))
            return False

        util.debug('Service call {}.{} returned with status code {} - changed states:\n{}'.format(domain, service, res.status_code, res.text))
        return res.status_code == 200

    def set_light_state(self, entity_ids, state, brightness):
        util.debug('Setting light state of {} to {} with brightness {}'.format(entity_ids, state, brightness))
        #brightness = self.__clip(brightness, 0, 254)
        state = 'on' if brightness > 0 else 'off'
        service_data = {'entity_id': entity_ids}

        if state == 'on':
            service_data['brightness'] = brightness

        return self.call_service('light', 'turn_{}'.format(state), service_data)